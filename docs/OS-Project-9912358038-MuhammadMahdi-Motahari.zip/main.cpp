#include <iostream>
#include <fstream>

using namespace std;

int main(int argi, char *argc[]){
	ofstream wf(argc[2], ios::out | ios::binary);
	ifstream rf(argc[1], ios::in | ios::binary);
	if(!rf.is_open()){
		cout << "\033[1;41minput file is not exist!!\033[1;41m" << endl;
		return 0;
	}
	char tmp;
	while(!rf.eof()){
		rf.read(&tmp,1);
		wf.write(&tmp,1);
		if(rf.eof())
			break;
	}
	return 0;
}
